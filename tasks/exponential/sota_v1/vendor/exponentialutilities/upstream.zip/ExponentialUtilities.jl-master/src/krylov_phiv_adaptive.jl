# Krylov phiv with internal time-stepping
"""
    expv_timestep(ts,A,b[;adaptive,tol,kwargs...]) -> U

Evaluates the matrix exponentiation-vector product using time stepping

```math
u = \\exp(tA)b
```

`ts` is an array of time snapshots for u, with `U[:,j] ≈ u(ts[j])`. `ts` can
also be just one value, in which case only the end result is returned and `U`
is a vector.

The time stepping formula of Niesen & Wright is used [^1]. If the time step
`tau` is not specified, it is chosen according to (17) of Niesen & Wright. If
`adaptive==true`, the time step and Krylov subspace size adaptation scheme of
Niesen & Wright is used, the relative tolerance of which can be set using the
keyword parameter `tol`. The delta and gamma parameters of the adaptation
scheme can also be adjusted.

Set `verbose=true` to print out the internal steps (for debugging). For the
other keyword arguments, consult `arnoldi` and `phiv`, which are used
internally.

Note that this function is just a special case of `phiv_timestep` with a more
intuitive interface (vector `b` instead of a n-by-1 matrix `B`).

# Arguments

  - `ts` or `t`: requested output time(s).
  - `A`: square matrix or matrix-free operator satisfying the
    Matrix-Free Operator Interface page in the manual.
  - `b`: initial vector.

# Keywords

`adaptive`, `tol`, `tau`, `m`, `iop`, `opnorm`, `ishermitian`, `delta`,
`gamma`, `NA`, and `verbose` are forwarded to [`phiv_timestep`](@ref).

# Returns

A vector for scalar `t`, or a matrix whose column `j` corresponds to `ts[j]`.

# Examples

```julia
A = [-2.0 1.0; 0.0 -1.0]
b = [1.0, 0.0]
expv_timestep(0.1, A, b; tol = 1.0e-8)
```

[^1]: Niesen, J., & Wright, W. (2009). A Krylov subspace algorithm for
    evaluating the φ-functions in exponential integrators. arXiv preprint
    arXiv:0907.4631.
"""
function expv_timestep(
        ts::Vector{tType},
        A, b; kwargs...
    ) where {tType <: Real}
    U = similar(b, size(A, 1), length(ts))
    return expv_timestep!(U, ts, A, b; kwargs...)
end
function expv_timestep(t::tType, A, b; kwargs...) where {tType <: Real}
    u = similar(b, size(A, 1))
    return expv_timestep!(u, t, A, b; kwargs...)
end
"""
    expv_timestep!(u,t,A,b[;kwargs]) -> u

Non-allocating version of [`expv_timestep`](@ref).

# Arguments

  - `u` or `U`: output vector or output matrix, overwritten in place.
  - `t` or `ts`: requested output time(s).
  - `A`: square matrix or matrix-free operator.
  - `b`: initial vector.

# Keywords

  - `caches`: optional reusable workspace tuple from the internal timestep-cache
    constructor.
  - Remaining keywords have the same meaning as for [`expv_timestep`](@ref).

# Returns

The mutated `u` or `U`.

# Examples

```julia
A = [-2.0 1.0; 0.0 -1.0]
b = [1.0, 0.0]
u = similar(b)
expv_timestep!(u, 0.1, A, b; tol = 1.0e-8)
```
"""
function expv_timestep!(
        u::AbstractVector{T}, t::tType, A, b::AbstractVector{T};
        caches = nothing, kwargs...
    ) where {T <: Number, tType <: Real}
    # `phiv_timestep!` accepts a vector output and a vector `b` (one φ₀ term)
    # directly, so no `reshape`/`[t]` allocation is needed.
    ts1 = _singleton_ts(caches, t)
    phiv_timestep!(u, ts1, A, b; caches = caches, kwargs...)
    return u
end
function expv_timestep!(
        U::AbstractMatrix{T}, ts::AbstractVector{tType}, A, b::AbstractVector{T};
        kwargs...
    ) where {T <: Number, tType <: Real}
    return phiv_timestep!(U, ts, A, b; kwargs...)
end
"""
    phiv_timestep(ts,A,B[;adaptive,tol,kwargs...]) -> U

Evaluates the linear combination of phi-vector products using time stepping

```math
u = \\varphi_0(tA)b_0 + t\\varphi_1(tA)b_1 + \\cdots + t^p\\varphi_p(tA)b_p
```

`ts` is an array of time snapshots for u, with `U[:,j] ≈ u(ts[j])`. `ts` can
also be just one value, in which case only the end result is returned and `U`
is a vector.

The time stepping formula of Niesen & Wright is used [^1]. If the time step
`tau` is not specified, it is chosen according to (17) of Niesen & Wright. If
`adaptive==true`, the time step and Krylov subspace size adaptation scheme of
Niesen & Wright is used, the relative tolerance of which can be set using the
keyword parameter `tol`. The delta and gamma parameters of the adaptation
scheme can also be adjusted.

The adaptation scheme drives the internal error estimate below `tol` times a
scalar operator-norm scale of `A`. By default (`opnorm === nothing`) that scale
is estimated matrix-free from the Arnoldi Hessenberg built on the first Krylov
step, so `opnorm(A, Inf)` is never evaluated: this needs no operator method
beyond `mul!` -- suitable for matrix types (e.g. sparse GPU arrays) that do not
support `opnorm` -- and reflects `A`'s action on the Krylov subspace the
exponential actually explores. The first Arnoldi step supplies the scale used
to seed the initial `tau`. Pass `opnorm` as a precomputed scalar (a norm or
bound) or a function `opnorm(A, Inf)` to override the estimate with an explicit
operator-norm scale, which additionally seeds the initial `tau`.

When encountering a happy breakdown in the Krylov subspace construction, the
time step is set to the remainder of the time interval since time stepping is
no longer necessary.

Set `verbose=true` to print out the internal steps (for debugging). For the
other keyword arguments, consult `arnoldi` and `phiv`, which are used
internally.

# Arguments

  - `ts` or `t`: requested output time(s).
  - `A`: square matrix or matrix-free operator satisfying the
    Matrix-Free Operator Interface page in the manual.
  - `B`: matrix whose columns are the coefficients `b_0, ..., b_p`.

# Keywords

  - `tau`: initial internal step size. `0` selects an estimate.
  - `m`: maximum Krylov dimension per internal step.
  - `tol`: requested relative tolerance for adaptive stepping.
  - `opnorm`: `nothing`, a scalar bound, or callable `(A, Inf) -> bound`.
  - `adaptive`: enable joint step-size and Krylov-dimension adaptation.
  - `iop`, `correct`, `caches`, `delta`, `ishermitian`, `gamma`, `NA`, and
    `verbose`: advanced Arnoldi, correction, workspace, and adaptation controls.

# Returns

A vector for scalar `t`, or a matrix whose column `j` is the requested linear
combination at `ts[j]`.

# Examples

```julia
A = [-2.0 1.0; 0.0 -1.0]
B = [1.0 0.5; 0.0 0.0]
phiv_timestep(0.1, A, B; tol = 1.0e-8)
```
"""
function phiv_timestep(ts::Vector{tType}, A, B; kwargs...) where {tType <: Real}
    U = Matrix{eltype(B)}(undef, size(A, 1), length(ts))
    return phiv_timestep!(U, ts, A, B; kwargs...)
end
function phiv_timestep(t::tType, A, B; kwargs...) where {tType <: Real}
    u = Vector{eltype(B)}(undef, size(A, 1))
    return phiv_timestep!(u, t, A, B; kwargs...)
end
"""
    phiv_timestep!(U,ts,A,B[;kwargs]) -> U

Non-allocating version of [`phiv_timestep`](@ref).

# Arguments

  - `u` or `U`: output vector or matrix, overwritten in place.
  - `t` or `ts`: requested output time(s).
  - `A`: square matrix or matrix-free operator.
  - `B`: coefficient matrix for the phi-function combination.

# Keywords

The keywords are the same as for [`phiv_timestep`](@ref).

# Returns

The mutated `u` or `U`.

# Examples

```julia
A = [-2.0 1.0; 0.0 -1.0]
B = [1.0 0.5; 0.0 0.0]
u = similar(B, size(B, 1))
phiv_timestep!(u, 0.1, A, B; tol = 1.0e-8)
```
"""
function phiv_timestep!(
        u::AbstractVector{T}, t::tType, A, B::AbstractMatrix{T};
        caches = nothing, kwargs...
    ) where {T <: Number, tType <: Real}
    # Pass the vector output straight through (the matrix method accepts a
    # `AbstractVecOrMat` and writes a single snapshot directly into `u`), and take
    # the length-1 `ts` from the phiv cache when available, so the scalar-time
    # entry point allocates neither a `reshape` nor a `[t]`.
    ts1 = _singleton_ts(caches, t)
    phiv_timestep!(u, ts1, A, B; caches = caches, kwargs...)
    return u
end
# Length-1 `ts` buffer for the scalar-time methods: reuse the phiv cache's slot
# when the caller supplied caches and the time is `Float64` (the buffer's type);
# otherwise fall back to a fresh vector. Both arms yield a concretely-typed
# vector for a given `t`.
function _singleton_ts(caches::Tuple, t::Float64)
    ts1 = (caches[5]::PhivCache).ts1
    @inbounds ts1[1] = t
    return ts1
end
_singleton_ts(_, t) = [t]
# Snapshot-count and snapshot-column accessors so `phiv_timestep!` can write its
# output either into the columns of a matrix `U` (multiple time snapshots) or
# directly into a vector `u` (a single snapshot). The vector path lets the
# scalar-time wrappers avoid a per-call `reshape(u, n, 1)` (an Array-header
# allocation).
_nsnapshots(U::AbstractMatrix) = size(U, 2)
_nsnapshots(::AbstractVector) = 1
_snapshotcol(U::AbstractMatrix, j) = @view(U[:, j])
_snapshotcol(u::AbstractVector, _) = u
# Column accessors for the coefficient argument `B`, so `expv_timestep!` can pass
# its vector `b` straight through (a single `phi_0` term, p = 0) without a
# `reshape(b, n, 1)` allocation. A vector `b` has one column, only ever indexed 1.
_ncoeffs(B::AbstractMatrix) = size(B, 2)
_ncoeffs(::AbstractVector) = 1
_coeffcol(B::AbstractMatrix, j) = @view(B[:, j])
_coeffcol(b::AbstractVector, _) = b

function phiv_timestep!(
        U::AbstractVecOrMat{T}, ts::AbstractVector{tType}, A, B::AbstractVecOrMat{T};
        tau::Real = 0.0,
        m::Int = min(10, size(A, 1)), tol::Real = 1.0e-7,
        opnorm = nothing, iop::Int = 0,
        correct::Bool = false, caches = nothing, adaptive = false,
        delta::Real = 1.2,
        ishermitian::Bool = LinearAlgebra.ishermitian(A),
        gamma::Real = 0.8, NA::Int = 0,
        verbose = false
    ) where {T <: Number, tType <: Real}
    # The adaptive tolerance is `tol` times a scalar operator-norm scale of `A`.
    # By default (`opnorm === nothing`) that scale is estimated matrix-free from
    # the Arnoldi Hessenberg on the first Krylov step (below): it needs no
    # operator method beyond `mul!`, so it works for matrix types (e.g. sparse
    # GPU arrays) that do not support `opnorm`, and it reflects `A`'s action on
    # the Krylov subspace the exponential actually explores. Passing `opnorm` as
    # a scalar (a precomputed norm or bound) or a function `opnorm(A, Inf)`
    # overrides that estimate and additionally seeds the initial `tau`.
    arnoldi_scale = opnorm === nothing
    abstol = nothing
    if !arnoldi_scale
        opn = opnorm isa Number ? opnorm : opnorm(A, Inf)
        abstol = tol * opn
        if iszero(tau)
            b0norm = norm(_coeffcol(B, 1), Inf)
            tau = 10 / opn *
                (
                abstol * ((m + 1) / ℯ)^(m + 1) * sqrt(2 * pi * (m + 1)) /
                    (4 * opn * b0norm)
            )^(1 / m)
            verbose && println("Initial time step unspecified, chosen to be $tau")
        end
    end
    verbose && abstol !== nothing && println("Absolute tolerance: $abstol")
    # Initialization
    n = size(U, 1)
    issorted(ts) || sort!(ts)
    tend = ts[end]
    # In the matrix-free default the operator-norm scale is unknown until the
    # first Krylov step, so both `abstol` and the initial `tau` are seeded then
    # (below). Use the whole interval as a placeholder meanwhile.
    seed_arnoldi_tau = arnoldi_scale && iszero(tau)
    if seed_arnoldi_tau
        tau = tend
    end
    p = _ncoeffs(B) - 1
    @assert length(ts) == _nsnapshots(U) "Dimension mismatch"
    @assert n == size(A, 1) == size(A, 2) == size(B, 1) "Dimension mismatch"
    if caches == nothing
        u = similar(B, T, n)              # stores the current state
        W = similar(B, T, n, p + 1)         # stores the w vectors
        P = similar(B, T, n, p + 2)         # stores output from phiv!
        V_tmp = similar(B, T, n, m + 1)
        H_tmp = fill(zero(T), m + 1, m)
        Ks = KrylovSubspace{T, T, real(T), typeof(V_tmp), Matrix{T}}(
            m, m, false, zero(real(T)), false, V_tmp, H_tmp
        ) # stores output from arnoldi!. Here we support also GPUs
        phiv_cache = nothing         # cache used by phiv!
    else
        u, W, P, Ks, phiv_cache = caches
        @assert length(u) == n&&size(W, 1) == n && size(P, 1) == n "Dimension mismatch"
        # W and P may be bigger than actually needed
        W = @view(W[:, 1:(p + 1)])
        P = @view(P[:, 1:(p + 2)])
    end
    copyto!(u, _coeffcol(B, 1)) # u(0) = b0
    # Reuse the phiv cache's coefficient scratch when available (avoids a per-call
    # allocation); fall back to a fresh vector on the uncached path. Both branches
    # yield a Vector{T}, so `coeffs` stays concretely typed.
    coeffs = (phiv_cache isa PhivCache) ? phiv_cache.coeffs : ones(T, p)
    if adaptive # initialization step for the adaptive scheme
        if ishermitian
            iop = 2 # does not have an effect on arnoldi!, just for flops estimation
        end
        if iszero(NA)
            _A = convert(AbstractMatrix, A)
            if isa(_A, SparseMatrixCSC)
                NA = nnz(_A)
            else
                NA = count(!iszero, _A) # not constant operation, should be best avoided
            end
        end
    end

    t = 0.0       # current time
    snapshot = 1  # which snapshot to compute next
    num_timesteps = 0
    while t < tend # time stepping loop
        if t + tau > tend # last step
            tau = tend - t
        end
        # Part 1: compute w0...wp using the recurrence relation (16)
        copyto!(@view(W[:, 1]), u) # w0 = u(t)
        @inbounds for l in 1:(p - 1) # compute cl = t^l/l!
            coeffs[l + 1] = coeffs[l] * t / l
        end
        @views @inbounds for j in 1:p
            mul!(W[:, j + 1], A, W[:, j])
            for l in 0:(p - j)
                axpy!(coeffs[l + 1], _coeffcol(B, j + l + 1), W[:, j + 1])
            end
        end
        # Part 2: compute ϕp(tau*A)wp using Krylov, possibly with adaptation
        arnoldi!(Ks, A, @view(W[:, end]); tol = tol, m = m, iop = iop)
        if abstol === nothing
            # Matrix-free default: estimate the operator norm from the Krylov
            # Hessenberg (already the quantity the adaptation below uses), and
            # seed the initial substep from it (Niesen-Wright (17)) rather than
            # stepping the whole interval. Apply the adaptation safety factor
            # because this scale is a Krylov-subspace estimate rather than an
            # operator-norm bound. Both are set on the first step only.
            opn = LinearAlgebra.opnorm(getH(Ks), 1)
            abstol = tol * opn
            if seed_arnoldi_tau
                b0norm = norm(_coeffcol(B, 1), Inf)
                tau = min(
                    tend - t,
                    gamma * 10 / opn * (
                        abstol * ((m + 1) / ℯ)^(m + 1) * sqrt(2 * pi * (m + 1)) /
                            (4 * opn * b0norm)
                    )^(1 / m)
                )
            end
            verbose && println("Absolute tolerance (Arnoldi estimate): $abstol")
        end
        # A zero Krylov vector spans an invariant subspace too, and its term is exactly zero.
        breakdown = Ks.wasbreakdown || iszero(Ks.beta)
        if breakdown
            tau = tend - t
        end
        _, epsilon = _phiv!(P, tau, Ks, p + 1, phiv_cache, correct, ExpMethodHigham2005Base())
        verbose && println("t = $t, m = $m, tau = $tau, error estimate = $epsilon")
        # A happy breakdown means the Krylov subspace is already A-invariant, so
        # `_phiv!` is exact and the error estimate carries no information to adapt on:
        # `m` no longer changes it, which would leave `kappa == 1` below.
        if adaptive && !breakdown
            omega = (tend / tau) * (epsilon / abstol)
            epsilon_old = epsilon
            m_old = m
            tau_old = tau
            q = m / 4
            kappa = 2.0
            maxtau = tend - t
            while omega > delta # inner loop of Algorithm 3
                m_new, tau_new,
                    q,
                    kappa = _phiv_timestep_adapt(
                    m, tau, epsilon, m_old,
                    tau_old, epsilon_old, q,
                    kappa,
                    gamma, omega, maxtau, n, p,
                    NA, iop,
                    LinearAlgebra.opnorm(
                        getH(Ks),
                        1
                    ),
                    verbose
                )
                m, m_old = m_new, m
                tau, tau_old = tau_new, tau
                # Compute ϕp(tau*A)wp using the new parameters
                arnoldi!(Ks, A, @view(W[:, end]); tol = tol, m = m, iop = iop)
                _, epsilon_new = _phiv!(P, tau, Ks, p + 1, phiv_cache, correct, ExpMethodHigham2005Base())
                epsilon, epsilon_old = epsilon_new, epsilon
                omega = (tend / tau) * (epsilon / abstol)
                verbose && println("  * m = $m, tau = $tau, error estimate = $epsilon")
            end
        end
        # Part 3: update u using (15)
        lmul!(tau^p, copyto!(u, @view(P[:, end - 1])))
        @inbounds for l in 1:(p - 1) # compute cl = tau^l/l!
            coeffs[l + 1] = coeffs[l] * tau / l
        end
        @views @inbounds for j in 0:(p - 1)
            axpy!(coeffs[j + 1], W[:, j + 1], u)
        end
        # Fill out all snapshots in between the current step
        while snapshot <= length(ts) && t + tau >= ts[snapshot]
            tau_snapshot = ts[snapshot] - t
            u_snapshot = _snapshotcol(U, snapshot)
            _phiv!(P, tau_snapshot, Ks, p + 1, phiv_cache, correct, ExpMethodHigham2005Base())
            lmul!(tau_snapshot^p, copyto!(u_snapshot, @view(P[:, end - 1])))
            @inbounds for l in 1:(p - 1) # compute cl = tau^l/l!
                coeffs[l + 1] = coeffs[l] * tau_snapshot / l
            end
            @views @inbounds for j in 0:(p - 1)
                axpy!(coeffs[j + 1], W[:, j + 1], u_snapshot)
            end
            snapshot += 1
        end

        t += tau
        num_timesteps += 1
    end
    verbose && println("Completed after $num_timesteps time step(s)")

    return U
end
# Helper functions for phiv_timestep!
function _phiv_timestep_adapt(
        m, tau, epsilon, m_old, tau_old, epsilon_old, q, kappa,
        gamma, omega, maxtau, n, p, NA, iop, Hnorm, verbose
    )
    # Compute new m and tau (Algorithm 4)
    if tau_old > tau
        q = log(tau / tau_old) / log(epsilon / epsilon_old) - 1
    end # else keep q the same
    tau_new = tau * (gamma / omega)^(1 / (q + 1))
    tau_new = min(max(tau_new, tau / 5), 2 * tau, maxtau)
    if m_old < m
        kappa = (epsilon / epsilon_old)^(1 / (m_old - m))
    end # else keep kappa the same
    m_new = m + ceil(Int, log(omega / gamma) / log(kappa))
    m_new = min(max(m_new, div(3 * m, 4), 1), Int(ceil(4 * m / 3)))
    verbose && println("  - Proposed new m: $m_new, new tau: $tau_new")
    # Compare costs of using new m vs new tau (23)
    cost_tau = _phiv_timestep_estimate_flops(m, tau_new, n, p, NA, iop, Hnorm, maxtau)
    cost_m = _phiv_timestep_estimate_flops(m_new, tau, n, p, NA, iop, Hnorm, maxtau)
    verbose && println("  - Cost to use new m: $cost_m flops, new tau: $cost_tau flops")
    if cost_tau < cost_m
        m_new = m
    else
        tau_new = tau
    end
    return m_new, tau_new, q, kappa
end
function _phiv_timestep_estimate_flops(m, tau, n, p, NA, iop, Hnorm, maxtau)
    # Estimate flops for the update of W and u
    flops_W = 2 * (p - 1) * (NA + n)
    flops_u = (2 * p + 1) * n
    # Estimate flops for arnoldi!
    if iop == 0
        iop = m
    end
    flops_matvec = 2 * m * NA
    flops_vecvec = 0
    for i in 1:m
        flops_vecvec += 3 * min(i, iop)
    end
    # Estimate flops for phiv! (7)
    MH = 44 / 3 + 2 * ceil(max(0.0, log2(Hnorm / 5.37)))
    flops_phiv = round(Int, MH * (m + p)^3)

    flops_onestep = flops_W + flops_u + flops_matvec + flops_vecvec + flops_phiv
    return flops_onestep * Int(ceil(maxtau / tau))
end
function _phiv_timestep_caches(u_prototype, maxiter::Int, p::Int)
    n = length(u_prototype)
    T = eltype(u_prototype)
    u = similar(u_prototype)                      # stores the current state
    W = Matrix{T}(undef, n, p + 1)                  # stores the w vectors
    P = Matrix{T}(undef, n, p + 2)                  # stores output from phiv!
    Ks = KrylovSubspace{T}(n, maxiter)            # stores output from arnoldi!
    phiv_cache = PhivCache(u_prototype, maxiter, p + 1)       # cache used by phiv! (need +1 for error estimation)
    return u, W, P, Ks, phiv_cache
end
